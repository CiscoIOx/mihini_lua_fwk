require 'sched'
require 'shell.telnet'

-- Start a telnet server on port 1234
-- Once this program is started , you can start a Lua VM through telnet
-- using the following command: telnet localhost 1234
local function run_server()
  shell.telnet.init {
    address     = '0.0.0.0',
    port        = 1234,
    editmode    = "edit",
    historysize = 100 }
end

local function main()
  -- Create a thread to start the telnet server
  sched.run(run_server)
  -- Starting the sched main loop to execute the previous task
  sched.loop()
end

main()

