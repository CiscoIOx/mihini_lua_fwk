Migration Script C Example: the header file
=========

~~~~{.c}
#ifndef MIGRATIONSCRIPT_H_
#define MIGRATIONSCRIPT_H_

int luaopen_agent_migration(lua_State* L);

#endif /* MIGRATIONSCRIPT_H_ */
~~~~

